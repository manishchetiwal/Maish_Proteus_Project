#define RCC_APB2ENR   (*(volatile unsigned int*)0x40021018)
#define GPIOA_CRL     (*(volatile unsigned int*)0x40010800)
#define GPIOA_ODR     (*(volatile unsigned int*)0x4001080C)

int main(void) {
    // Enable clock for GPIOA (bit 2)
    RCC_APB2ENR |= (1 << 2);

    // Set PA5 as output, push-pull, 10 MHz
    GPIOA_CRL &= ~(0xF << (4 * 5));  // Clear bits for PA5
    GPIOA_CRL |=  (0x1 << (4 * 5));  // MODE = 01 (10 MHz), CNF = 00 (Push-Pull)

    // Turn ON LED connected to PA5
    GPIOA_ODR |= (1 << 5);

    while (1) {
        // Infinite loop
    }
}
